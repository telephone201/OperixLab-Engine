<?php
include "con_insta.php";

$permissions = 'instagram_business_basic%2Cinstagram_business_manage_messages%2Cinstagram_business_manage_comments%2Cinstagram_business_content_publish%2Cinstagram_business_manage_insights';

$login_url = "https://www.facebook.com/v23.0/dialog/oauth?client_id=$app_id&redirect_uri=$redirect_uri&scope=$permissions&auth_type=rerequest";


$login_url = "https://www.instagram.com/oauth/authorize?force_reauth=true&client_id=$app_id&redirect_uri=$redirect_uri&response_type=code&scope=$permissions";

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login with Instagram</title>
</head>
<body>
    <h2>Login with Instagram (via Facebook)</h2>
    <a href="<?php echo $login_url; ?>">Click here to login with Instagram</a>
</body>
</html>
