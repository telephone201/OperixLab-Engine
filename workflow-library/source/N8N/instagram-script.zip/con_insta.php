<?php
$app_id = '';
$app_secret = '';
$redirect_uri = 'https://yourdomain.com/instagram_callback.php';



?>