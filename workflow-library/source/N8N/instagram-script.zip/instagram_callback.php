<?php
include "con_insta.php";


// Instagram App بيانات
$ig_app_id     = $app_id;
$ig_app_secret = $app_secret; // ضيف السر بتاع انستجرام
$redirect_uri  = $redirect_uri;

if (isset($_GET['code'])) {
    $code = $_GET['code'];

    // Step 1: Exchange code for access token
    $token_url = "https://api.instagram.com/oauth/access_token";

    $post_fields = [
        'client_id'     => $ig_app_id,
        'client_secret' => $ig_app_secret,
        'grant_type'    => 'authorization_code',
        'redirect_uri'  => $redirect_uri,
        'code'          => $code,
    ];

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $token_url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $post_fields);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    curl_close($ch);

    $params = json_decode($response, true);

    echo "<h2>Access Token Response:</h2>";
    echo "<pre>" . print_r($params, true) . "</pre>";

    if (isset($params['access_token'])) {
        $access_token = $params['access_token'];
        $user_id = $params['user_id'];

        // Step 2: Get user info
        $user_url = "https://graph.instagram.com/{$user_id}?fields=id,username,account_type&access_token=$access_token";
        $user_info = json_decode(file_get_contents($user_url), true);

        echo "<h2>User Info:</h2>";
        echo "<pre>" . print_r($user_info, true) . "</pre>";
    }

} else {
    echo "Login failed or canceled.";
}


/* By Ahmed Elserafy www.ahmedelserafy.com */