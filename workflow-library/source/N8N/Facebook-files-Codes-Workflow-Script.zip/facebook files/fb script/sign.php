<?php
/*
** created by Ahmed Elserafy - ahmedelserafy.com
*/


// ضع هنا الـ Page ID و Page Access Token
$page_id = "";
$page_token = "";

// الحقول اللي عايز تشترك فيها
$fields = [
    'subscribed_fields' => 'messages,feed,messaging_postbacks,mention'
];

// API call
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://graph.facebook.com/v19.0/{$page_id}/subscribed_apps?access_token={$page_token}");
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($fields));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($ch);
curl_close($ch);

// Show response
echo "<pre>" . $response . "</pre>";
?>
