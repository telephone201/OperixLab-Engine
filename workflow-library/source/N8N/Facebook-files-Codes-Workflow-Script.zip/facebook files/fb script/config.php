<?php
$app_id         = '';
$app_secret     = '';
$redirect_uri   = 'https://example.com/callback.php';


/*
** created by Ahmed Elserafy - ahmedelserafy.com
*/
?>