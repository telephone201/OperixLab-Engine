<?php
/*
** created by Ahmed Elserafy - ahmedelserafy.com
*/

include "config.php";

if (isset($_GET['code'])) {
    $code = $_GET['code'];

    // Step 1: Get Access Token
    $token_url = "https://graph.facebook.com/v19.0/oauth/access_token?" .
        "client_id=$app_id&redirect_uri=$redirect_uri&client_secret=$app_secret&code=$code";

    $response = file_get_contents($token_url);
    $params = json_decode($response, true);
    $access_token = $params['access_token'];

    // Step 2: Get User Info
    $graph_url = "https://graph.facebook.com/me?fields=id,name,email&access_token=$access_token";
    $user = json_decode(file_get_contents($graph_url), true);

    // Step 3: Get Pages
    $pages_url = "https://graph.facebook.com/me/accounts?access_token=$access_token";
    $pages = json_decode(file_get_contents($pages_url), true);

    echo "<h2>User Info:</h2>";
    echo "<pre>" . print_r($user, true) . "</pre>";

    echo "<h2>Pages:</h2>";
    echo "<pre>" . print_r($pages, true) . "</pre>";

} else {
    echo "Login failed or canceled.";
}

?>
