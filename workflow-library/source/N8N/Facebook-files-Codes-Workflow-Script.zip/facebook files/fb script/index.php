<?php
/*
** created by Ahmed Elserafy - ahmedelserafy.com
*/
include "config.php";


$permissions = 'email,pages_show_list,pages_manage_metadata,email,pages_show_list,pages_messaging,pages_manage_metadata,pages_manage_posts,pages_read_engagement,pages_read_user_content,pages_messaging,pages_manage_engagement';

$login_url = "https://www.facebook.com/v19.0/dialog/oauth?client_id=$app_id&redirect_uri=$redirect_uri&scope=$permissions&auth_type=rerequest";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login with Facebook</title>
</head>
<body>
    <h2>Login with Facebook</h2>
    <a href="<?php echo $login_url; ?>">Click here to login</a>
</body>
</html>
