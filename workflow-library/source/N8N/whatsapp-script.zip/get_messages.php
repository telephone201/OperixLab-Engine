<?php
include "config.php";
session_start();

if (!isset($_SESSION['user_id'])) {
    http_response_code(403);
    exit('Unauthorized');
}

$client_id = $_SESSION['user_id'];
$conversation_id = (int)($_GET['conversation_id'] ?? 0);
$last_message_id = (int)($_GET['last_id'] ?? 0);

if (!$conversation_id) exit;

// ✅ لو أول مرة يفتح المحادثة → هات كل الرسائل
if ($last_message_id > 0) {
    $stmt = $pdo->prepare("SELECT * FROM messages WHERE conversation_id = ? AND client_id = ? AND id > ? ORDER BY id ASC");
    $stmt->execute([$conversation_id, $client_id, $last_message_id]);
} else {
    $stmt = $pdo->prepare("SELECT * FROM messages WHERE conversation_id = ? AND client_id = ? ORDER BY id ASC");
    $stmt->execute([$conversation_id, $client_id]);
}

$messages = $stmt->fetchAll(PDO::FETCH_ASSOC);

// ✅ لو مفيش رسائل جديدة اخرج بدون طباعة
if (!$messages) exit;

foreach ($messages as $msg):
    $text = nl2br(htmlspecialchars($msg['message_text']));
    $cls = ($msg['message_direction'] === 'incoming') ? 'incoming' : 'outgoing';
    $cls = ($msg['message_direction'] === 'incoming') ? 'incoming' : 'outgoing';
    $timestamp = date("Y-m-d h:i A", strtotime($msg['created_at'])); // ✅ تنسيق التاريخ والوقت
?>
<div class="message <?= $cls ?>" data-id="<?= $msg['id'] ?>" style="white-space: pre-line;">
  <?= $text ?>
 <div class="text-muted small mt-1" style="font-size: 11px;">
    <?= $timestamp ?>
  </div>
</div>
<?php endforeach; ?>

<?php
// ✅ تحديث حالة الرسائل كـ "مقروءة" (اختياري)
$ids = array_column($messages, 'id');
if (!empty($ids)) {
    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $update = $pdo->prepare("UPDATE messages SET is_read = 1 WHERE id IN ($placeholders)");
    $update->execute($ids);
}
?>
