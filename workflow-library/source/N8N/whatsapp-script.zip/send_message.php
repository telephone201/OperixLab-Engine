<?php
include "config.php";
include "whatsapp_api.php";

session_start();
$client_id = $_SESSION['user_id'] ?? 0;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['conversation_id'], $_POST['message'])) {
    $conversation_id = (int) $_POST['conversation_id'];
    $message_text = trim($_POST['message']);

    // جلب رقم الهاتف من المحادثة
    $stmt = $pdo->prepare("SELECT phone_number FROM conversations WHERE id = ?");
    $stmt->execute([$conversation_id]);
    $conversation = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$conversation) {
        die("❌ Conversation not found.");
    }

    $phone_number = $conversation['phone_number'];

    // إنشاء كائن API
    $whatsapp = new WhatsAppAPI($pdo, $client_id);

    // إرسال الرسالة
    $response = $whatsapp->sendTextMessage($phone_number, $message_text);

    // التحقق من حالة الإرسال
    if ($response['success']) {
        $message_id = $response['message_id'] ?? null;

        // حفظ الرسالة في قاعدة البيانات
        $stmt = $pdo->prepare("
            INSERT INTO messages (conversation_id, sender_type, message_text, message_type, message_direction, client_id, message_id, status)
            VALUES (?, 'admin', ?, 'text', 'outgoing', ?, ?, 'sent')
        ");
        $stmt->execute([$conversation_id, $message_text, $client_id, $message_id]);
    } else {
        // حفظ فشل الإرسال في السجلات
        $error_msg = $response['error'] ?? 'Unknown error';

        $stmt = $pdo->prepare("
            INSERT INTO messages (conversation_id, sender_type, message_text, message_type, message_direction, client_id, status)
            VALUES (?, 'admin', ?, 'text', 'outgoing', ?, 'failed')
        ");
        $stmt->execute([$conversation_id, "[Failed] {$message_text}\nError: {$error_msg}", $client_id]);
    }

    // إعادة التوجيه بعد الإرسال
    header("Location: dashboard.php?conversation_id=" . $conversation_id);
    exit;
}
?>
