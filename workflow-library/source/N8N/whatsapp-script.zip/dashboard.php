<?php
session_start();
include "config.php";
 
// ✅ تأكد إن المستخدم عامل تسجيل دخول
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}

$client_id = $_SESSION['user_id'];

// ✅ جلب المحادثات الخاصة بالعميل
//$stmt = $pdo->prepare("SELECT * FROM conversations WHERE client_id = ? ORDER BY last_message_at DESC");
//$stmt = $pdo->prepare("SELECT * FROM conversations WHERE client_id = ? ORDER BY last_message_at DESC  LIMIT 50 ");
/*$stmt = $pdo->prepare("
  SELECT * FROM conversations 
  WHERE client_id = ? 
  ORDER BY 
    (SELECT COUNT(*) FROM messages 
     WHERE messages.conversation_id = conversations.id 
     AND messages.is_read = 0 
     AND messages.message_direction = 'incoming') DESC,
    last_message_at DESC
  LIMIT 50
");*/

$stmt = $pdo->prepare("
  SELECT 
    c.*, 
    (
      SELECT COUNT(*) 
      FROM messages m 
      WHERE m.conversation_id = c.id 
      AND m.is_read = 0 
      AND m.message_direction = 'incoming'
    ) AS unread_count
  FROM conversations c
  WHERE c.client_id = ?
  ORDER BY unread_count DESC, c.last_message_at DESC
  LIMIT $show_sidebar_conversations
");


$stmt->execute([$client_id]);
$conversations = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<audio id="newMessageSound" src="plucky.mp3" preload="auto"></audio>

<meta charset="UTF-8">
<title>Dashboard - WhatsApp Panel</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<style>
body {
  background: #f8f9fa;
  font-family: "Segoe UI", sans-serif;
  margin: 0;
  padding: 0;
}

/* ✅ الشريط الجانبي */
#sidebar {
  height: 100vh;
  overflow-y: auto;
  border-right: 1px solid #ddd;
  background: #fff;
}

/* ✅ منطقة الرسائل */
#messages-container {
  height: 70vh;
  overflow-y: auto;
  background: #fff;
  border-radius: 10px;
  padding: 15px;
  scroll-behavior: smooth;
}

/* ✅ فقاعات الرسائل */
.message {
  margin-bottom: 10px;
  padding: 8px 12px;
  border-radius: 12px;
  max-width: 80%;
  word-wrap: break-word;
  line-height: 1.4;
  font-size: 0.95rem;
}
.message.incoming {
  background-color: #e9ecef;
  align-self: flex-start;
}
.message.outgoing {
  background-color: #007bff;
  color: #fff;
  align-self: flex-end;
}

/* ✅ منطقة الشات */
#chat-box {
  display: flex;
  flex-direction: column;
  height: 100%;
}

/* ✅ مدخل الرسائل */
#message-input {
  flex: 1;
  resize: none;
  min-height: 45px;
  max-height: 100px;
}

/* ✅ عناصر قائمة المحادثات */
.conversation-item {
  cursor: pointer;
  padding: 10px;
  border-bottom: 1px solid #eee;
  transition: background 0.2s;
}
.conversation-item:hover {
  background: #f1f1f1;
}
.conversation-item.active {
  background: #d9ebff;
}
.conversation-item.unread {
  background-color: #fff3cd !important;
  border-left: 4px solid #ffc107;
}
.unread {
  background-color: #fff3cd;
}

/* ✅ الزر السفلي (برمجة المبرمج) */
#chat-box > div:last-child {
  text-align: center;
  margin-top: 1rem !important;
}
#chat-box > div:last-child a {
  color: blue !important;
  display: block !important;
  text-decoration: none;
  font-size: 0.9rem;
}
#chat-box > div:last-child a:hover {
  text-decoration: underline;
}

/* ✅ تحسين على الموبايل */
@media (max-width: 768px) {
  #sidebar {
    height: auto;
    border-right: none;
    border-bottom: 1px solid #ddd;
  }

  .row {
    flex-direction: column;
  }

  .col-md-3,
  .col-md-9 {
    width: 100% !important;
    max-width: 100% !important;
    flex: 0 0 100%;
  }

  #messages-container {
    height: 65vh;
  }

  #send-form {
    flex-direction: column;
    gap: 0.5rem;
  }

  #message-input {
    width: 100%;
  }

  #chat-box {
    padding-bottom: 1rem;
  }

  .conversation-item {
    font-size: 0.9rem;
    padding: 8px;
  }

  #conversation-header {
    flex-direction: column;
    gap: 8px;
    align-items: flex-start;
  }

  #conversation-title {
    font-size: 1.1rem;
  }
}

/* ✅ تحسين على الشاشات الصغيرة جدًا */
@media (max-width: 480px) {
  #messages-container {
    height: 60vh;
  }

  .message {
    font-size: 0.85rem;
  }

  #send-form button {
    width: 100%;
  }

  #conversation-title {
    font-size: 1rem;
  }
}
</style>
</head>
<body>

<div class="container-fluid">


  <div class="row">
    <!-- ✅ الشريط الجانبي -->
    <div class="col-md-3 bg-white p-0" id="sidebar">
    <a href="settings.php" class="btn btn-sm btn-secondary ">
      Settings
    </a>        
    <a class="btn btn-sm btn-warning" href="logout.php">Logout</a>

      <div class="p-3 border-bottom d-flex justify-content-between align-items-center">
          
        <h5 class="m-0">Conversations</h5>
        <button class="btn btn-sm btn-success" data-bs-toggle="modal" data-bs-target="#newChatModal">+ New</button>
      </div>

      <!-- 🔹 نافذة إعادة تسمية المحادثة -->
      <div class="modal fade" id="renameModal" tabindex="-1">
        <div class="modal-dialog">
          <form class="modal-content" id="renameForm">
            <div class="modal-header">
              <h5 class="modal-title">Rename Contact</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
              <input type="hidden" name="conversation_id" id="rename_conversation_id">
              <input type="text" class="form-control" name="name" id="rename_name" placeholder="Enter new name" required>
            </div>
            <div class="modal-footer">
              <button class="btn btn-primary">Save</button>
            </div>
          </form>
        </div>
      </div>

      <!-- 🔹 قائمة المحادثات -->
      <div id="conversations-list">
        <?php if ($conversations): ?>
          <?php foreach ($conversations as $conv): ?>
            <div class="conversation-item <?php if($conv['unread_count'] > 0){echo 'unread';} ?>" 
                 data-id="<?= htmlspecialchars($conv['id']) ?>" 
                 data-name="<?= htmlspecialchars($conv['name'] ?: $conv['phone_number']) ?>"
                 data-phone="<?= htmlspecialchars($conv['phone_number']) ?>">

            <?php if($conv['unread_count'] > 0){ echo "<span class='badge' style='color:red;'>{$conv['unread_count']}</span> ";} ?>

              <strong><?= htmlspecialchars($conv['name'] ?: $conv['phone_number']) ?></strong><br>
              <small class="text-muted"><?= htmlspecialchars($conv['last_message_at']) ?></small>
            </div>
          <?php endforeach; ?>
        <?php else: ?>
          <p class="text-muted p-3">No conversations yet.</p>
        <?php endif; ?>
      </div>
        <div class="text-center my-3">
          <button id="loadMoreBtn" class="btn btn-outline-primary btn-sm">Load More</button>
        </div>


    </div>

    <!-- ✅ منطقة الشات -->
    <div class="col-md-9 p-4">
      <div id="conversation-header" class="d-flex justify-content-between align-items-center mb-3">
        <h5 id="conversation-title" class="m-0 text-primary"></h5>
        <button id="rename-btn" class="btn btn-sm btn-outline-secondary d-none">Rename</button>
        <button id="exit-btn" class="btn btn-sm btn-outline-danger d-none">Exit</button>

      </div>

      <div id="chat-box">
        <div id="messages-container" class="d-flex flex-column mb-3"></div>
        <form id="send-form" class="d-flex gap-2">
          <textarea id="message-input" class="form-control" placeholder="Type your message..." required></textarea>
          <button class="btn btn-primary">Send</button>
        </form>

      </div>
    </div>
      
      
  </div>
</div>

<!-- 🔹 نافذة إنشاء محادثة جديدة -->
<div class="modal fade" id="newChatModal" tabindex="-1">
  <div class="modal-dialog">
    <form class="modal-content" id="newChatForm">
      <div class="modal-header">
        <h5 class="modal-title">Start New Chat</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <div class="mb-3">
          <label>Contact Name</label>
          <input type="text" class="form-control" name="name" required>
        </div>
        <div class="mb-3">
          <label>Phone Number (with country code)</label>
          <input type="text" class="form-control" name="phone_number" required>
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-success">Create</button>
      </div>
    </form>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
let currentConversationId = null;
let lastMessageId = 0;

// ✅ تحميل الرسائل عند الضغط على محادثة
$(document).on('click', '.conversation-item', function() {
  $(this).removeClass('active');
  $(this).removeClass('unread');
  $(this).addClass('active');
  //$this.find('.badge').remove(); // ✅ شيل عداد الرسائل الجديدة فوريًا

  currentConversationId = $(this).data('id');
  const name = $(this).data('name');
  const phone = $(this).data('phone');
  $('#conversation-title').text(`${name} (${phone})`);
  $('#rename-btn').removeClass('d-none');
  $('#rename_conversation_id').val(currentConversationId);
  $('#rename_name').val(name);

  lastMessageId = 0; // Reset
  //loadMessages(currentConversationId, true);
    
$('#exit-btn').removeClass('d-none');

    
});

// ✅ دالة تحميل الرسائل
function loadMessages(conversationId, all = false) {
  $.get('get_messages.php', { conversation_id: conversationId, last_id: all ? 0 : lastMessageId }, function(res) {
    if (res.trim()) {
      $('#messages-container').append(res);
      $('#messages-container').scrollTop($('#messages-container')[0].scrollHeight);

      // تحديث آخر ID
      const ids = $('#messages-container .message[data-id]').map(function() {
        return parseInt($(this).data('id'));
      }).get();
      if (ids.length > 0) lastMessageId = Math.max(...ids);
    }
  });
}

// ✅ إرسال رسالة
$('#send-form').on('submit', function(e) {
  e.preventDefault();
  if (!currentConversationId) return alert('Please select a conversation first.');

  let msg = $('#message-input').val().trim();
  if (!msg) return;

  $.post('send_message.php', {
    conversation_id: currentConversationId,
    message: msg
  }, function() {
    $('#message-input').val('');
    loadMessages(currentConversationId, true);
  });
});

// ✅ إعادة تسمية المحادثة
$('#rename-btn').on('click', function() {
  $('#renameModal').modal('show');
});

$('#renameForm').on('submit', function(e) {
  e.preventDefault();
  $.post('rename_conversation.php', $(this).serialize(), function() {
    $('#renameModal').modal('hide');
    location.reload();
  });
});

// ✅ إنشاء محادثة جديدة
$('#newChatForm').on('submit', function(e) {
  e.preventDefault();
  $.post('create_conversation.php', $(this).serialize(), function() {
    location.reload();
  });
});

// ✅ تحديث تلقائي كل 4 ثواني — يجيب فقط الرسائل الجديدة
setInterval(() => {
  if (currentConversationId) loadMessages(currentConversationId, false);
}, <?php echo $check_message_every; ?>);
    
    
// ✅ فحص المحادثات الجديدة كل دقيقة
let lastNewCount = 0; // تخزين آخر عدد تنبيهات تم تشغيلها

setInterval(() => {
  checkNewConversations();
}, <?php echo $check_conversation_every; ?>);

function checkNewConversations() {
  $.get('check_new_conversations.php', function(data) {
    try {
      let result = JSON.parse(data);
      const newCount = result.new_count || 0;

      // ✅ لو فيه محادثات جديدة ولسه العدد زاد → شغّل الجرس مرة واحدة فقط
      if (newCount > lastNewCount) {
        playNotificationSound();
        refreshConversations();
      }

      // ✅ حدث العدد الحالي للمقارنة في المرة الجاية
      lastNewCount = newCount;

    } catch (e) {
      console.error('Error checking conversations:', e);
    }
  });
}


// ✅ تشغيل صوت التنبيه مرة واحدة
function playNotificationSound() {
  const sound = document.getElementById('newMessageSound');
  sound.currentTime = 0;
  sound.play().catch(() => {});
}


// ✅ تلوين المحادثات الغير مقروءة بلون مختلف
function highlightUnreadConversations() {
  // تقدر هنا تنادي ملف refresh_conversations.php لو عندك
  // أو تضيف CSS مثلاً للمحادثات الغير مقروءة
  $('#conversations-list .conversation-item').each(function() {
    if ($(this).hasClass('unread')) {
      $(this).css('background', '#fff3cd'); // لون أصفر باهت
    }
  });
}


// ✅ خروج من المحادثة لتقليل التحميل
function exitConversation() {
  currentConversationId = null;
  lastMessageId = 0;
  $('#conversation-title').text('');
  $('#rename-btn').addClass('d-none');
  $('#messages-container').html('<p class="text-muted">Select a conversation</p>');
}
 
$('#exit-btn').on('click', function() {
  exitConversation();
});
    
let lastLoaded = <?php echo $show_sidebar_conversations; ?>; // أول 50 محادثة تم تحميلهم

// ✅ تحميل المزيد من المحادثات
$('#loadMoreBtn').on('click', function() {
  $.get('load_more_conversations.php', { offset: lastLoaded }, function(res) {
    if (res.trim()) {
      $('#conversations-list').append(res);
      lastLoaded += 50;
    } else {
      $('#loadMoreBtn').prop('disabled', true).text('No more conversations');
    }
  });
});

// ✅ جرس تنبيه عند وصول رسالة جديدة
function playNotificationSound() {
  const sound = document.getElementById('newMessageSound');
  sound.currentTime = 0;
  sound.play().catch(() => {});
}


// ✅ تحديث مظهر المحادثات الغير مقروءة
function refreshConversations() {
  $.get('refresh_conversations.php', function(res) {
    $('#conversations-list').html(res);
  });
}

// ✅ عند فتح محادثة يتم تحديث حالتها إلى مقروءة
function markConversationRead(conversationId) {
  $.post('mark_read.php', { conversation_id: conversationId });
}

// تعديل عند فتح المحادثة:
$(document).on('click', '.conversation-item', function() {
  $('.conversation-item').removeClass('active');
  $(this).addClass('active');
  currentConversationId = $(this).data('id');
  const name = $(this).data('name');
    
  const phone = $(this).data('phone');
  $('#conversation-title').text(`${name} (${phone})`);
    
  //$('#conversation-title').text(name);
  $('#rename-btn').removeClass('d-none');
  $('#rename_conversation_id').val(currentConversationId);
  $('#rename_name').val(name);
  lastMessageId = 0;
  loadMessages(currentConversationId, true);
  $('#exit-btn').removeClass('d-none');

  // ✅ تحديث حالة القراءة
  markConversationRead(currentConversationId);
});
/*
document.addEventListener("DOMContentLoaded", function() {
  // المكان الصحيح للعنصر
  const chatBox = document.querySelector("#chat-box");

  // البحث عن عنصر المبرمج
  const creditDiv = chatBox ? chatBox.querySelector("div:last-child") : null;
  const creditLink = creditDiv ? creditDiv.querySelector("a") : null;

  // القيم الأصلية
  const expected = {
    href: "https://ahmedelserafy.com/",
    text: "Programmed By Ahmed Elserafy",
    color: "blue",
    display: "block"
  };

  // دالة للتحقق
  function verifyCredit() {
    try {
      if (!chatBox || !creditDiv || !creditLink) throw "Credit element missing";

      // التحقق من مكان العنصر
      if (creditDiv.parentElement !== chatBox) throw "Credit element misplaced";

      // التحقق من النص والرابط
      if (creditLink.textContent.trim() !== expected.text) throw "Credit text modified";
      if (creditLink.getAttribute("href") !== expected.href) throw "Credit link modified";

      // التحقق من اللون والعرض
      const linkStyle = window.getComputedStyle(creditLink);
      if (linkStyle.color !== "rgb(0, 0, 255)" && linkStyle.color !== "blue") throw "Credit color changed";
      if (linkStyle.display !== expected.display) throw "Credit display changed";

      // ✅ كل شيء تمام
      return true;
    } catch (err) {
      console.warn("Unauthorized modification detected:", err);
      // هنا تقدر تحدد التصرف
      document.body.innerHTML = "<h1 style='color:red;text-align:center;margin-top:50px'>Unauthorized script modification detected!</h1>";
      return false;
    }
  }

  // التحقق أول ما الصفحة تحمل
  verifyCredit();

});
*/



</script>



</body>
</html>
