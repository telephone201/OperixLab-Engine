<?php
session_start();
include "config.php";

// --- معالجة طلب تسجيل الدخول ---
$login_error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'login') {
    // نأخذ القيم بدون FILTER_SANITIZE (حسب تفضيلك الحالي) لكن نستخدم trim
    $username = isset($_POST['username']) ? trim($_POST['username']) : '';
    //$password = isset($_POST['password']) ? $_POST['password'] : '';
    $password = $_POST['password'];

    if ($username === '' || $password === '') {
        $login_error = 'Please fill username and password';
    } else {
        // استخدام prepared statement لمنع SQL injection
        $stmt = $pdo->prepare("SELECT * FROM clients WHERE username = ?");
        $stmt->execute([$username]);
        $user = $stmt->fetch();
        //print_r($user);
        if ($user && isset($user['password']) && password_verify($password, $user['password'])) {
            // ناجح: أمان الجلسة

            //$_SESSION['username'] = $user['username'];


            if($user['status'] == 1 ){
                
                session_regenerate_id(true);
                $_SESSION['user_id'] = $user['id'];
                
                // إعادة توجيه بعد تسجيل الدخول
                header('Location: dashboard.php');

 
            }else{
                $login_error = 'Your account is not active';
            }



            //exit;
        } else {
            
            $login_error = 'Username or password incorrect';
        }
    }
}


?>
<!doctype html>
<html lang="ar">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Login</title>
<style>
    body { font-family: Arial, sans-serif; background:#f5f5f5; padding:30px; }
    .card { max-width:420px; margin:40px auto; background:#fff; padding:24px; border-radius:8px; box-shadow:0 6px 18px rgba(0,0,0,0.08); }
    input[type="text"], input[type="password"] { width:100%; padding:10px 12px; margin:8px 0 14px; box-sizing:border-box; }
    button { padding:10px 16px; cursor:pointer; border:none; border-radius:6px; background:#007bff; color:white; }
    .error { background:#ffe6e6; padding:10px; border-radius:6px; color:#900; margin-bottom:12px; }
    .note { font-size:13px; color:#666; margin-top:10px; }
</style>
</head>
<body>
<div class="card">
    <h2 style="margin-top:0">Login</h2>

    <?php if ($login_error): ?>
        <div class="error"><?=htmlspecialchars($login_error)?></div>
    <?php endif; ?>

    <form method="post" action="">
        <input type="hidden" name="action" value="login">
        <label for="username">Username</label>
        <input id="username" name="username" type="text" autocomplete="username" required>

        <label for="password">Password</label>
        <input id="password" name="password" type="password" autocomplete="current-password" required>

        <button type="submit">Login</button>
    </form>
    <p style="margin-top:15px; font-size:14px;">
        Sign up? <a href="sign_up.php">Sign up here</a>.
    </p>
    <p class="note"></p>
</div>
</body>
</html>
