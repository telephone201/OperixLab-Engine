<?php
include "config.php";
session_start();

if (!isset($_SESSION['user_id'])) {
    http_response_code(403);
    exit('Unauthorized');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['conversation_id'], $_POST['name'])) {
    $conversation_id = (int)$_POST['conversation_id'];
    $name = trim($_POST['name']);

    // sanitize
    $name = preg_replace('/[^a-zA-Z0-9\s\p{Arabic}]/u', '', $name);

    $stmt = $pdo->prepare("UPDATE conversations SET name = ? WHERE id = ?");
    $stmt->execute([$name, $conversation_id]);

    echo 'success';
}
