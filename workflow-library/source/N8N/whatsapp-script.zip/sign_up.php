<?php
include "config.php";

$register_msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'register') {

    $name     = trim($_POST['name'] ?? '');
    $username = trim($_POST['username'] ?? '');
    $email    = trim($_POST['email'] ?? '');
    $phone    = trim($_POST['phone'] ?? '');
    $password = $_POST['password'] ?? '';

    $username = trim($_POST['username'] ?? '');
    $username = strtolower($username); // تخليه lowercase لو حابب
    $username = preg_replace('/[^a-z0-9]/i', '', $username); // يزيل أي رموز أو مسافات أو حروف غير انجليزية


    if ($name === '' || $username === '' || $email === '' || $phone === '' || $password === '') {
        $register_msg = 'Please fill in all fields.';
    } else {
        // check if username or email already exists
        $check = $pdo->prepare("SELECT id FROM clients WHERE username = ? OR email = ?");
        $check->execute([$username, $email]);
        if ($check->fetch()) {
            $register_msg = 'Username or Email already exists.';
        } else {
            // hash password
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $status = 1;

            $stmt = $pdo->prepare("INSERT INTO clients (name, username, email, password, phone, status) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->execute([$name, $username, $email, $hash, $phone, $status]);

            $register_msg = 'Account created successfully. You can now login.';
        }
    }
}
?>

<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Register</title>
<style>
    body { font-family: Arial, sans-serif; background:#f5f5f5; padding:30px; }
    .card { max-width:420px; margin:40px auto; background:#fff; padding:24px; border-radius:8px; box-shadow:0 6px 18px rgba(0,0,0,0.08); }
    input[type="text"], input[type="email"], input[type="password"], input[type="tel"] {
        width:100%; padding:10px 12px; margin:8px 0 14px; box-sizing:border-box;
    }
    button { padding:10px 16px; cursor:pointer; border:none; border-radius:6px; background:#007bff; color:white; }
    .msg { background:#e6f3ff; padding:10px; border-radius:6px; color:#004080; margin-bottom:12px; }
    .error { background:#ffe6e6; padding:10px; border-radius:6px; color:#900; margin-bottom:12px; }
</style>
</head>
<body>
<div class="card">
    <h2 style="margin-top:0">Create Account</h2>

    <?php if ($register_msg): ?>
        <div class="<?= strpos($register_msg, 'successfully') !== false ? 'msg' : 'error' ?>">
            <?= htmlspecialchars($register_msg) ?>
        </div>
    <?php endif; ?>

    <form method="post" action="">
        <input type="hidden" name="action" value="register">

        <label for="name">Full Name</label>
        <input id="name" name="name" type="text" required>

        <label for="username">Username (English and no spaces)</label>
        <input id="username" name="username" type="text" required>

        <label for="email">Email</label>
        <input id="email" name="email" type="email" required>

        <label for="phone">Phone (Including + like +201066666)</label>
        <input id="phone" name="phone" type="tel" required>

        <label for="password">Password</label>
        <input id="password" name="password" type="password" required>

        <button type="submit">Register</button>
    </form>

    <p style="margin-top:15px; font-size:14px;">
        Already have an account? <a href="index.php">Login here</a>.
    </p>
</div>
</body>
</html>
