<?php
include "config.php";
session_start();

if (!isset($_SESSION['user_id'])) exit;

$client_id = $_SESSION['user_id'];
$offset = (int)($_GET['offset'] ?? 0);

$limit = $show_sidebar_conversations_more;
$offset = max(0, (int)($_GET['offset'] ?? 0)); // تأكيد إنه رقم موجب

$sql = "
  SELECT * FROM conversations 
  WHERE client_id = :client_id 
  ORDER BY last_message_at DESC 
  LIMIT $limit OFFSET $offset
";
$stmt = $pdo->prepare($sql);
$stmt->execute(['client_id' => $client_id]);

$conversations = $stmt->fetchAll(PDO::FETCH_ASSOC);

foreach ($conversations as $conv): ?>
  <div class="conversation-item <?= $conv['unread_count'] > 0 ? 'bg-warning-subtle' : '' ?>" 
       data-id="<?= htmlspecialchars($conv['id']) ?>" 
       data-name="<?= htmlspecialchars($conv['name'] ?: $conv['phone_number']) ?>">
    <strong><?= htmlspecialchars($conv['name'] ?: $conv['phone_number']) ?></strong><br>
    <small class="text-muted"><?= htmlspecialchars($conv['last_message_at']) ?></small>
  </div>
<?php endforeach; ?>
