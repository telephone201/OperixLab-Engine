<?php
include "config.php";
session_start();

if (!isset($_SESSION['user_id'])) {
    http_response_code(403);
    exit('Unauthorized');
}

$client_id = $_SESSION['user_id'];
$conversation_id = (int)($_POST['conversation_id'] ?? 0);

if (!$conversation_id) {
    http_response_code(400);
    exit('Missing conversation_id');
}

// تأكيد وجود العمود is_read في الجدول
try {
    $pdo->query("ALTER TABLE messages ADD COLUMN is_read TINYINT(1) DEFAULT 0");
} catch (PDOException $e) {
    // العمود موجود بالفعل، نكمل عادي
}

// نعلّم كل الرسائل الواردة (incoming) كمقروءة
$stmt = $pdo->prepare("
    UPDATE messages 
    SET is_read = 1 
    WHERE conversation_id = ? 
      AND client_id = ? 
      AND message_direction = 'incoming'
");
$stmt->execute([$conversation_id, $client_id]);

echo json_encode(['success' => true]);
