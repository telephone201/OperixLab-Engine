<?php
include "config.php";
session_start();

if (!isset($_SESSION['user_id'])) {
    http_response_code(403);
    echo json_encode(['new_count' => 0]);
    exit;
}

$client_id = $_SESSION['user_id'];

$stmt = $pdo->prepare("
    SELECT COUNT(DISTINCT conversation_id) AS new_count
    FROM messages
    WHERE client_id = ? AND message_direction = 'incoming' AND is_read = 0
");
$stmt->execute([$client_id]);
$row = $stmt->fetch(PDO::FETCH_ASSOC);

echo json_encode(['new_count' => (int)$row['new_count']]);
