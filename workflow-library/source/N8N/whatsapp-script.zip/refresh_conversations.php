<?php
include "config.php";
session_start();

if (!isset($_SESSION['user_id'])) {
    http_response_code(403);
    exit;
}

$client_id = $_SESSION['user_id'];

// نجيب المحادثات، نخلي الغير مقروءة في الأول
$stmt = $pdo->prepare("
    SELECT c.*, 
           COALESCE(SUM(CASE WHEN m.is_read = 0 AND m.message_direction = 'incoming' THEN 1 ELSE 0 END), 0) AS unread_count
    FROM conversations c
    LEFT JOIN messages m ON c.id = m.conversation_id
    WHERE c.client_id = ?
    GROUP BY c.id
    ORDER BY unread_count DESC, c.last_message_at DESC
    LIMIT 50
");
$stmt->execute([$client_id]);
$conversations = $stmt->fetchAll(PDO::FETCH_ASSOC);

// نرجّع HTML يعرضهم بنفس شكل العناصر في الـ sidebar
foreach ($conversations as $conv): 
    $name = htmlspecialchars($conv['name'] ?: $conv['phone_number']);
    $isUnread = $conv['unread_count'] > 0;
?>
    <div class="conversation-item <?= $isUnread ? 'unread' : '' ?>" 
         data-id="<?= htmlspecialchars($conv['id']) ?>" 
         data-name="<?= $name ?>">
        <strong><?= $name ?></strong>
        <?php if ($isUnread): ?>
            <span class="badge bg-warning text-dark ms-2"><?= $conv['unread_count'] ?></span>
        <?php endif; ?>
        <br>
        <small class="text-muted"><?= htmlspecialchars($conv['last_message_at']) ?></small>
    </div>
<?php endforeach; ?>
