<?php
require_once 'config.php';

class WhatsAppAPI {
    private $pdo;
    private $clientId;
    private $accessToken;
    private $phoneNumberId;
    private $businessPhone;
    private $apiVersion;
    private $baseUrl;

    public function __construct(PDO $pdo, $clientId) {
        $this->pdo = $pdo;
        $this->clientId = $clientId;
        $this->loadClientData();
        $this->apiVersion = 'v21.0';
        $this->baseUrl = "https://graph.facebook.com/{$this->apiVersion}";
    }

    /**
     * تحميل بيانات العميل من قاعدة البيانات
     */
    private function loadClientData() {
        $stmt = $this->pdo->prepare("
            SELECT access_token, wb_account_id, phone 
            FROM clients 
            WHERE id = ?
        ");
        $stmt->execute([$this->clientId]);
        $data = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$data) {
            throw new Exception("Client not found for ID {$this->clientId}");
        }

        $this->accessToken = $data['access_token'];
        $this->phoneNumberId = $data['wb_account_id']; // الـ ID من Meta
        $this->businessPhone = $data['phone']; // رقم الهاتف الفعلي
    }

    /**
     * إرسال رسالة نصية
     */
    public function sendTextMessage($to, $message) {
        $data = [
            "messaging_product" => "whatsapp",
            "recipient_type" => "individual",
            "to" => $this->formatPhoneNumber($to),
            "type" => "text",
            "text" => [
                "preview_url" => true,
                "body" => $message
            ]
        ];

        return $this->sendRequest($data);
    }

    /**
     * إرسال صورة
     */
    public function sendImage($to, $imageUrl, $caption = '') {
        $data = [
            "messaging_product" => "whatsapp",
            "recipient_type" => "individual",
            "to" => $this->formatPhoneNumber($to),
            "type" => "image",
            "image" => [
                "link" => $imageUrl,
                "caption" => $caption
            ]
        ];

        return $this->sendRequest($data);
    }

    /**
     * إرسال ملف
     */
    public function sendDocument($to, $documentUrl, $filename, $caption = '') {
        $data = [
            "messaging_product" => "whatsapp",
            "recipient_type" => "individual",
            "to" => $this->formatPhoneNumber($to),
            "type" => "document",
            "document" => [
                "link" => $documentUrl,
                "filename" => $filename,
                "caption" => $caption
            ]
        ];

        return $this->sendRequest($data);
    }

    /**
     * رفع ملف إلى WhatsApp servers
     */
    public function uploadMedia($filePath, $type = 'image') {
        $url = "{$this->baseUrl}/{$this->phoneNumberId}/media";

        $postData = [
            'messaging_product' => 'whatsapp',
            'type' => $type,
            'file' => new CURLFile($filePath)
        ];

        $headers = [
            "Authorization: Bearer {$this->accessToken}"
        ];

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $postData,
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_SSL_VERIFYPEER => false
        ]);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        $result = json_decode($response, true);

        return [
            'success' => $httpCode === 200,
            'data' => $result,
            'http_code' => $httpCode
        ];
    }

    /**
     * إرسال الطلب إلى API
     */
    private function sendRequest($data) {
        $url = "{$this->baseUrl}/{$this->phoneNumberId}/messages";
        $headers = [
            "Content-Type: application/json",
            "Authorization: Bearer {$this->accessToken}"
        ];

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => json_encode($data),
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_SSL_VERIFYPEER => false
        ]);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);

        if ($error) {
            return ['success' => false, 'error' => 'CURL Error: ' . $error];
        }

        $result = json_decode($response, true);

        if ($httpCode >= 200 && $httpCode < 300 && isset($result['messages'])) {
            return [
                'success' => true,
                'message_id' => $result['messages'][0]['id'] ?? null,
                'data' => $result
            ];
        }

        return [
            'success' => false,
            'error' => $result['error']['message'] ?? 'Unknown error',
            'data' => $result
        ];
    }

    /**
     * تنسيق رقم الهاتف
     */
    private function formatPhoneNumber($phoneNumber) {
        $phoneNumber = preg_replace('/[^0-9+]/', '', $phoneNumber);
        if (substr($phoneNumber, 0, 1) !== '+') {
            $phoneNumber = '+' . $phoneNumber;
        }
        return $phoneNumber;
    }

    /**
     * جلب حالة الرسالة
     */
    public function getMessageStatus($messageId) {
        $url = "{$this->baseUrl}/{$messageId}";
        $headers = ["Authorization: Bearer {$this->accessToken}"];

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_SSL_VERIFYPEER => false
        ]);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        return [
            'success' => $httpCode === 200,
            'data' => json_decode($response, true)
        ];
    }
}

/**
 * دالة مساعدة لإرسال رسالة واتساب مباشرة
 */
function sendWhatsAppMessage(PDO $pdo, $clientId, $to, $message, $type = 'text', $mediaUrl = null, $filename = null) {
    $api = new WhatsAppAPI($pdo, $clientId);

    switch ($type) {
        case 'text':
            return $api->sendTextMessage($to, $message);
        case 'image':
            return $api->sendImage($to, $mediaUrl, $message);
        case 'document':
            return $api->sendDocument($to, $mediaUrl, $filename, $message);
        default:
            return ['success' => false, 'error' => 'نوع الرسالة غير مدعوم'];
    }
}

/**
 * دالة لإرسال رسالة ترحيب
 */
function sendWelcomeMessage(PDO $pdo, $clientId, $to, $name) {
    $message = "مرحباً {$name}! 👋\n\nشكراً لتواصلك معنا. سنقوم بالرد عليك في أقرب وقت ممكن.";
    return sendWhatsAppMessage($pdo, $clientId, $to, $message);
}
?>
