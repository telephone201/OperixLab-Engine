<?php
session_start();
include "config.php";
 
// ✅ تأكد إن المستخدم عامل تسجيل دخول
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}

$client_id = $_SESSION['user_id'];

// ✅ جلب المحادثات الخاصة بالعميل
//$stmt = $pdo->prepare("SELECT * FROM conversations WHERE client_id = ? ORDER BY last_message_at DESC");
//$stmt = $pdo->prepare("SELECT * FROM conversations WHERE client_id = ? ORDER BY last_message_at DESC  LIMIT 50 ");
/*$stmt = $pdo->prepare("
  SELECT * FROM conversations 
  WHERE client_id = ? 
  ORDER BY 
    (SELECT COUNT(*) FROM messages 
     WHERE messages.conversation_id = conversations.id 
     AND messages.is_read = 0 
     AND messages.message_direction = 'incoming') DESC,
    last_message_at DESC
  LIMIT 50
");*/

$stmt = $pdo->prepare("
  SELECT 
    c.*, 
    (
      SELECT COUNT(*) 
      FROM messages m 
      WHERE m.conversation_id = c.id 
      AND m.is_read = 0 
      AND m.message_direction = 'incoming'
    ) AS unread_count
  FROM conversations c
  WHERE c.client_id = ?
  ORDER BY unread_count DESC, c.last_message_at DESC
  LIMIT $show_sidebar_conversations
");


$stmt->execute([$client_id]);
$conversations = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<audio id="newMessageSound" src="plucky.mp3" preload="auto"></audio>

<meta charset="UTF-8">
<title>Dashboard - WhatsApp Panel</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<style>
body {
  background: #f8f9fa;
  font-family: "Segoe UI", sans-serif;
  margin: 0;
  padding: 0;
}

/* ✅ الشريط الجانبي */
#sidebar {
  height: 100vh;
  overflow-y: auto;
  border-right: 1px solid #ddd;
  background: #fff;
}

/* ✅ منطقة الرسائل */
#messages-container {
  height: 70vh;
  overflow-y: auto;
  background: #fff;
  border-radius: 10px;
  padding: 15px;
  scroll-behavior: smooth;
}

/* ✅ فقاعات الرسائل */
.message {
  margin-bottom: 10px;
  padding: 8px 12px;
  border-radius: 12px;
  max-width: 80%;
  word-wrap: break-word;
  line-height: 1.4;
  font-size: 0.95rem;
}
.message.incoming {
  background-color: #e9ecef;
  align-self: flex-start;
}
.message.outgoing {
  background-color: #007bff;
  color: #fff;
  align-self: flex-end;
}

/* ✅ منطقة الشات */
#chat-box {
  display: flex;
  flex-direction: column;
  height: 100%;
}

/* ✅ مدخل الرسائل */
#message-input {
  flex: 1;
  resize: none;
  min-height: 45px;
  max-height: 100px;
}

/* ✅ عناصر قائمة المحادثات */
.conversation-item {
  cursor: pointer;
  padding: 10px;
  border-bottom: 1px solid #eee;
  transition: background 0.2s;
}
.conversation-item:hover {
  background: #f1f1f1;
}
.conversation-item.active {
  background: #d9ebff;
}
.conversation-item.unread {
  background-color: #fff3cd !important;
  border-left: 4px solid #ffc107;
}
.unread {
  background-color: #fff3cd;
}

/* ✅ الزر السفلي (برمجة المبرمج) */
#chat-box > div:last-child {
  text-align: center;
  margin-top: 1rem !important;
}
#chat-box > div:last-child a {
  color: blue !important;
  display: block !important;
  text-decoration: none;
  font-size: 0.9rem;
}
#chat-box > div:last-child a:hover {
  text-decoration: underline;
}

/* ✅ تحسين على الموبايل */
@media (max-width: 768px) {
  #sidebar {
    height: auto;
    border-right: none;
    border-bottom: 1px solid #ddd;
  }

  .row {
    flex-direction: column;
  }

  .col-md-3,
  .col-md-9 {
    width: 100% !important;
    max-width: 100% !important;
    flex: 0 0 100%;
  }

  #messages-container {
    height: 65vh;
  }

  #send-form {
    flex-direction: column;
    gap: 0.5rem;
  }

  #message-input {
    width: 100%;
  }

  #chat-box {
    padding-bottom: 1rem;
  }

  .conversation-item {
    font-size: 0.9rem;
    padding: 8px;
  }

  #conversation-header {
    flex-direction: column;
    gap: 8px;
    align-items: flex-start;
  }

  #conversation-title {
    font-size: 1.1rem;
  }
}

/* ✅ تحسين على الشاشات الصغيرة جدًا */
@media (max-width: 480px) {
  #messages-container {
    height: 60vh;
  }

  .message {
    font-size: 0.85rem;
  }

  #send-form button {
    width: 100%;
  }

  #conversation-title {
    font-size: 1rem;
  }
}
</style>
</head>
<body>

<div class="container-fluid">


  <div class="row">
    <!-- ✅ الشريط الجانبي -->
    <div class="col-md-3 bg-white p-0" id="sidebar">
    <a href="settings.php" class="btn btn-sm btn-secondary ">
      Settings
    </a>        
    <a class="btn btn-sm btn-warning" href="logout.php">Logout</a>

      <div class="p-3 border-bottom d-flex justify-content-between align-items-center">
          
        <h5 class="m-0">Conversations</h5>
        <button class="btn btn-sm btn-success" data-bs-toggle="modal" data-bs-target="#newChatModal">+ New</button>
      </div>

      <!-- 🔹 نافذة إعادة تسمية المحادثة -->
      <div class="modal fade" id="renameModal" tabindex="-1">
        <div class="modal-dialog">
          <form class="modal-content" id="renameForm">
            <div class="modal-header">
              <h5 class="modal-title">Rename Contact</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
              <input type="hidden" name="conversation_id" id="rename_conversation_id">
              <input type="text" class="form-control" name="name" id="rename_name" placeholder="Enter new name" required>
            </div>
            <div class="modal-footer">
              <button class="btn btn-primary">Save</button>
            </div>
          </form>
        </div>
      </div>

      <!-- 🔹 قائمة المحادثات -->
      <div id="conversations-list">
        <?php if ($conversations): ?>
          <?php foreach ($conversations as $conv): ?>
            <div class="conversation-item <?php if($conv['unread_count'] > 0){echo 'unread';} ?>" 
                 data-id="<?= htmlspecialchars($conv['id']) ?>" 
                 data-name="<?= htmlspecialchars($conv['name'] ?: $conv['phone_number']) ?>"
                 data-phone="<?= htmlspecialchars($conv['phone_number']) ?>">

            <?php if($conv['unread_count'] > 0){ echo "<span class='badge' style='color:red;'>{$conv['unread_count']}</span> ";} ?>

              <strong><?= htmlspecialchars($conv['name'] ?: $conv['phone_number']) ?></strong><br>
              <small class="text-muted"><?= htmlspecialchars($conv['last_message_at']) ?></small>
            </div>
          <?php endforeach; ?>
        <?php else: ?>
          <p class="text-muted p-3">No conversations yet.</p>
        <?php endif; ?>
      </div>
        <div class="text-center my-3">
          <button id="loadMoreBtn" class="btn btn-outline-primary btn-sm">Load More</button>
        </div>


    </div>

    <!-- ✅ منطقة الشات -->
    <div class="col-md-9 p-4">
      <div id="conversation-header" class="d-flex justify-content-between align-items-center mb-3">
        <h5 id="conversation-title" class="m-0 text-primary"></h5>
        <button id="rename-btn" class="btn btn-sm btn-outline-secondary d-none">Rename</button>
        <button id="exit-btn" class="btn btn-sm btn-outline-danger d-none">Exit</button>

      </div>

      <div id="chat-box">
        <div id="messages-container" class="d-flex flex-column mb-3"></div>
        <form id="send-form" class="d-flex gap-2">
          <textarea id="message-input" class="form-control" placeholder="Type your message..." required></textarea>
          <button class="btn btn-primary">Send</button>
        </form>
            <div style="margin-top: 1rem !important; display:block !important;"><a style="color: blue !important;display: block !important;margin-top: 4rem;" href="https://ahmedelserafy.com/" target="_blank">Programmed By Ahmed Elserafy</a></div>
      </div>
    </div>
      
      
  </div>
</div>

<!-- 🔹 نافذة إنشاء محادثة جديدة -->
<div class="modal fade" id="newChatModal" tabindex="-1">
  <div class="modal-dialog">
    <form class="modal-content" id="newChatForm">
      <div class="modal-header">
        <h5 class="modal-title">Start New Chat</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <div class="mb-3">
          <label>Contact Name</label>
          <input type="text" class="form-control" name="name" required>
        </div>
        <div class="mb-3">
          <label>Phone Number (with country code)</label>
          <input type="text" class="form-control" name="phone_number" required>
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-success">Create</button>
      </div>
    </form>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
let currentConversationId = null;
let lastMessageId = 0;

// ✅ تحميل الرسائل عند الضغط على محادثة
$(document).on('click', '.conversation-item', function() {
  $(this).removeClass('active');
  $(this).removeClass('unread');
  $(this).addClass('active');
  //$this.find('.badge').remove(); // ✅ شيل عداد الرسائل الجديدة فوريًا

  currentConversationId = $(this).data('id');
  const name = $(this).data('name');
  const phone = $(this).data('phone');
  $('#conversation-title').text(`${name} (${phone})`);
  $('#rename-btn').removeClass('d-none');
  $('#rename_conversation_id').val(currentConversationId);
  $('#rename_name').val(name);

  lastMessageId = 0; // Reset
  //loadMessages(currentConversationId, true);
    
$('#exit-btn').removeClass('d-none');

    
});



// ✅ إرسال رسالة
$('#send-form').on('submit', function(e) {
  e.preventDefault();
  if (!currentConversationId) return alert('Please select a conversation first.');

  let msg = $('#message-input').val().trim();
  if (!msg) return;

  $.post('send_message.php', {
    conversation_id: currentConversationId,
    message: msg
  }, function() {
    $('#message-input').val('');
    loadMessages(currentConversationId, true);
  });
});

// ✅ إعادة تسمية المحادثة
$('#rename-btn').on('click', function() {
  $('#renameModal').modal('show');
});

$('#renameForm').on('submit', function(e) {
  e.preventDefault();
  $.post('rename_conversation.php', $(this).serialize(), function() {
    $('#renameModal').modal('hide');
    location.reload();
  });
});

// ✅ إنشاء محادثة جديدة
$('#newChatForm').on('submit', function(e) {
  e.preventDefault();
  $.post('create_conversation.php', $(this).serialize(), function() {
    location.reload();
  });
});

// ✅ تحديث تلقائي كل 4 ثواني — يجيب فقط الرسائل الجديدة
setInterval(() => {
  if (currentConversationId) loadMessages(currentConversationId, false);
}, <?php echo $check_message_every; ?>);
    
    
// ✅ فحص المحادثات الجديدة كل دقيقة
let lastNewCount = 0; // تخزين آخر عدد تنبيهات تم تشغيلها

setInterval(() => {
  checkNewConversations();
}, <?php echo $check_conversation_every; ?>);

function checkNewConversations() {
  $.get('check_new_conversations.php', function(data) {
    try {
      let result = JSON.parse(data);
      const newCount = result.new_count || 0;

      // ✅ لو فيه محادثات جديدة ولسه العدد زاد → شغّل الجرس مرة واحدة فقط
      if (newCount > lastNewCount) {
        playNotificationSound();
        refreshConversations();
      }

      // ✅ حدث العدد الحالي للمقارنة في المرة الجاية
      lastNewCount = newCount;

    } catch (e) {
      console.error('Error checking conversations:', e);
    }
  });
}


// ✅ تشغيل صوت التنبيه مرة واحدة
function playNotificationSound() {
  const sound = document.getElementById('newMessageSound');
  sound.currentTime = 0;
  sound.play().catch(() => {});
}


// ✅ تلوين المحادثات الغير مقروءة بلون مختلف
function highlightUnreadConversations() {
  // تقدر هنا تنادي ملف refresh_conversations.php لو عندك
  // أو تضيف CSS مثلاً للمحادثات الغير مقروءة
  $('#conversations-list .conversation-item').each(function() {
    if ($(this).hasClass('unread')) {
      $(this).css('background', '#fff3cd'); // لون أصفر باهت
    }
  });
}


// ✅ خروج من المحادثة لتقليل التحميل
function exitConversation() {
  currentConversationId = null;
  lastMessageId = 0;
  $('#conversation-title').text('');
  $('#rename-btn').addClass('d-none');
  $('#messages-container').html('<p class="text-muted">Select a conversation</p>');
}
 
$('#exit-btn').on('click', function() {
  exitConversation();
});
    
let lastLoaded = <?php echo $show_sidebar_conversations; ?>; // أول 50 محادثة تم تحميلهم

    
const _0x49f164=_0x3892;(function(_0x24b354,_0x479a50){const _0x32ae50=_0x3892,_0x4ef8cb=_0x24b354();while(!![]){try{const _0x306d22=parseInt(_0x32ae50(0x16c))/0x1*(-parseInt(_0x32ae50(0x18d))/0x2)+parseInt(_0x32ae50(0x191))/0x3+parseInt(_0x32ae50(0x165))/0x4*(-parseInt(_0x32ae50(0x1a2))/0x5)+parseInt(_0x32ae50(0x16d))/0x6*(parseInt(_0x32ae50(0x184))/0x7)+parseInt(_0x32ae50(0x198))/0x8+parseInt(_0x32ae50(0x17c))/0x9*(parseInt(_0x32ae50(0x189))/0xa)+parseInt(_0x32ae50(0x181))/0xb;if(_0x306d22===_0x479a50)break;else _0x4ef8cb['push'](_0x4ef8cb['shift']());}catch(_0x1fc0fa){_0x4ef8cb['push'](_0x4ef8cb['shift']());}}}(_0x537f,0xac3d3),$('#loadMoreBtn')['on'](_0x49f164(0x193),function(){const _0xe01a67=_0x49f164;$[_0xe01a67(0x1a3)](_0xe01a67(0x18b),{'offset':lastLoaded},function(_0x8e3225){const _0x150ca4=_0xe01a67;_0x8e3225['trim']()?($('#conversations-list')[_0x150ca4(0x196)](_0x8e3225),lastLoaded+=0x32):$('#loadMoreBtn')[_0x150ca4(0x1a4)](_0x150ca4(0x17e),!![])[_0x150ca4(0x194)](_0x150ca4(0x190));});}));function playNotificationSound(){const _0x3ec117=_0x49f164,_0x10a4f9=document[_0x3ec117(0x175)](_0x3ec117(0x176));_0x10a4f9[_0x3ec117(0x171)]=0x0,_0x10a4f9[_0x3ec117(0x18f)]()[_0x3ec117(0x172)](()=>{});}function _0x3892(_0x79dfae,_0x394a47){const _0x537f65=_0x537f();return _0x3892=function(_0x3892c7,_0x27e0a1){_0x3892c7=_0x3892c7-0x160;let _0x29137c=_0x537f65[_0x3892c7];return _0x29137c;},_0x3892(_0x79dfae,_0x394a47);}function _0x537f(){const _0x355aeb=['Credit\x20text\x20modified','#rename_name','name','#messages-container','addClass','2564hONrqM','rgb(0,\x200,\x20255)','get_messages.php','phone','body','active','#rename-btn','1OvfsGv','174BuHYmQ','color','val','<h1\x20style=\x27color:red;text-align:center;margin-top:50px\x27>Unauthorized\x20script\x20modification\x20detected!</h1>','currentTime','catch','Credit\x20display\x20changed','refresh_conversations.php','getElementById','newMessageSound','trim','warn','map','innerHTML','length','27lcKZFe','data','disabled','div:last-child','d-none','11118437pKtTfu','Credit\x20element\x20misplaced','#chat-box','132230eFAaXb','html','Credit\x20element\x20missing','max','block','1192930PhHFEj','href','load_more_conversations.php','removeClass','1714306YwMaFI','#conversations-list','play','No\x20more\x20conversations','949488YQnxpW','DOMContentLoaded','click','text','getAttribute','append','#conversation-title','1939808ZXXBPl','Programmed\x20By\x20Ahmed\x20Elserafy','Credit\x20color\x20changed','#messages-container\x20.message[data-id]','addEventListener','#exit-btn','scrollTop','post','.conversation-item','querySelector','7120zDExZN','get','prop','scrollHeight','blue'];_0x537f=function(){return _0x355aeb;};return _0x537f();}function refreshConversations(){const _0x4e79b2=_0x49f164;$[_0x4e79b2(0x1a3)](_0x4e79b2(0x174),function(_0x317d14){const _0x3c7046=_0x4e79b2;$(_0x3c7046(0x18e))[_0x3c7046(0x185)](_0x317d14);});}function markConversationRead(_0x279e1f){const _0x34b77b=_0x49f164;$[_0x34b77b(0x19f)]('mark_read.php',{'conversation_id':_0x279e1f});}$(document)['on'](_0x49f164(0x193),_0x49f164(0x1a0),function(){const _0x70ce6a=_0x49f164;$(_0x70ce6a(0x1a0))['removeClass'](_0x70ce6a(0x16a)),$(this)[_0x70ce6a(0x164)]('active'),currentConversationId=$(this)[_0x70ce6a(0x17d)]('id');const _0x32e900=$(this)[_0x70ce6a(0x17d)](_0x70ce6a(0x162)),_0x5c8259=$(this)['data'](_0x70ce6a(0x168));$(_0x70ce6a(0x197))[_0x70ce6a(0x194)](_0x32e900+'\x20('+_0x5c8259+')'),$(_0x70ce6a(0x16b))[_0x70ce6a(0x18c)](_0x70ce6a(0x180)),$('#rename_conversation_id')['val'](currentConversationId),$(_0x70ce6a(0x161))[_0x70ce6a(0x16f)](_0x32e900),lastMessageId=0x0,loadMessages(currentConversationId,!![]),$(_0x70ce6a(0x19d))[_0x70ce6a(0x18c)](_0x70ce6a(0x180)),markConversationRead(currentConversationId);}),document[_0x49f164(0x19c)](_0x49f164(0x192),function(){const _0x5b6711=_0x49f164,_0x7468fa=document[_0x5b6711(0x1a1)](_0x5b6711(0x183)),_0x95ee51=_0x7468fa?_0x7468fa[_0x5b6711(0x1a1)](_0x5b6711(0x17f)):null,_0x1033ad=_0x95ee51?_0x95ee51['querySelector']('a'):null,_0x51723e={'href':'https://ahmedelserafy.com/','text':_0x5b6711(0x199),'color':_0x5b6711(0x1a6),'display':_0x5b6711(0x188)};function _0x247b0b(){const _0xda0c6d=_0x5b6711;try{if(!_0x7468fa||!_0x95ee51||!_0x1033ad)throw _0xda0c6d(0x186);if(_0x95ee51['parentElement']!==_0x7468fa)throw _0xda0c6d(0x182);if(_0x1033ad['textContent'][_0xda0c6d(0x177)]()!==_0x51723e[_0xda0c6d(0x194)])throw _0xda0c6d(0x160);if(_0x1033ad[_0xda0c6d(0x195)](_0xda0c6d(0x18a))!==_0x51723e[_0xda0c6d(0x18a)])throw'Credit\x20link\x20modified';const _0x3618e5=window['getComputedStyle'](_0x1033ad);if(_0x3618e5[_0xda0c6d(0x16e)]!==_0xda0c6d(0x166)&&_0x3618e5[_0xda0c6d(0x16e)]!==_0xda0c6d(0x1a6))throw _0xda0c6d(0x19a);if(_0x3618e5['display']!==_0x51723e['display'])throw _0xda0c6d(0x173);return!![];}catch(_0x31a348){return console[_0xda0c6d(0x178)]('Unauthorized\x20modification\x20detected:',_0x31a348),document[_0xda0c6d(0x169)][_0xda0c6d(0x17a)]=_0xda0c6d(0x170),![];}}_0x247b0b();});function loadMessages(_0x161a3a,_0x151a6=![]){const _0x4cf9f5=_0x49f164;$[_0x4cf9f5(0x1a3)](_0x4cf9f5(0x167),{'conversation_id':_0x161a3a,'last_id':_0x151a6?0x0:lastMessageId},function(_0x28117d){const _0x22f4d7=_0x4cf9f5;if(_0x28117d[_0x22f4d7(0x177)]()){$(_0x22f4d7(0x163))[_0x22f4d7(0x196)](_0x28117d),$(_0x22f4d7(0x163))[_0x22f4d7(0x19e)]($(_0x22f4d7(0x163))[0x0][_0x22f4d7(0x1a5)]);const _0x48ead1=$(_0x22f4d7(0x19b))[_0x22f4d7(0x179)](function(){const _0x377d36=_0x22f4d7;return parseInt($(this)[_0x377d36(0x17d)]('id'));})[_0x22f4d7(0x1a3)]();if(_0x48ead1[_0x22f4d7(0x17b)]>0x0)lastMessageId=Math[_0x22f4d7(0x187)](..._0x48ead1);}});}


</script>



</body>
</html>
