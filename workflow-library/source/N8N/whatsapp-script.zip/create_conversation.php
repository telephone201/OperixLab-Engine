<?php
include "config.php";
session_start();

$client_id = $_SESSION['user_id'] ?? 0;
$name = trim($_POST['name'] ?? '');
$phone = trim($_POST['phone_number'] ?? '');

if ($name && $phone) {
    $stmt = $pdo->prepare("INSERT INTO conversations (name, phone_number, client_id, started_at, last_message_at) VALUES (?, ?, ?, NOW(), NOW())");
    $stmt->execute([$name, $phone, $client_id]);
}
