<?php
// إعدادات الاتصال بقاعدة البيانات — عدّل القيم التالية
$db_host = 'localhost';
$db_name = 'whatsapp';
$db_user = 'root';
$db_pass = '';


$check_message_every                = 10 * 1000; // عدد الثواني لعرض اذا كان هناك رسائل جديده او لا قم بتغيير رقم 10 لما تريد
$check_conversation_every           = 60 * 1000; // عدد الثواني لتحديث اذا كان هناك محادثه جديده او لا قم بتحديث رقم 60 
$show_sidebar_conversations         = 10; // عدد المحادثات للعرض فى القائمة الجانبية
$show_sidebar_conversations_more    = 10; // عدد المحادثات الجديدة التي سيتم تحميلها بعد الضغط على load more





$dsn = "mysql:host=$db_host;dbname=$db_name;charset=utf8mb4";



// اتصال PDO بسيط وآمن
try {
    $pdo = new PDO($dsn, $db_user, $db_pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
} catch (Exception $e) {
    // لا تعرض تفاصيل الاتصال للمستخدم في بيئة الإنتاج
    die('خطأ في الاتصال بقاعدة البيانات.');
}













?>